<?php
class User {
    private int $id;
    private string $nombre;
    private string $correo;
    private string $avatarImage;

// Constructor
    public function __construct(int $id,string $nombre,string $correo,string $avatarImage)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->correo = $correo;
        $this->avatarImage = $avatarImage;
    }
    //Getters
    public function getId()
    {
        return $this->id;
    }
    public function getName()
    {
        return $this->nombre;
    }
    public function getEmail()
    {
        return $this->correo;
    }
    public function getAvatarImage()
    {
        return $this->avatarImage;
    }
    //Setters
    public function setId(int $id)
    {
        $this->id = $id;
    }
    public function setNombre(string $nombre)
    {
        $this->nombre;
    }
    public function setEmail(string $correo)
    {
        $this->correo;
    }
    public function setAvatarImage(string $avatar)
    {
        $this->avatar;
    }
}