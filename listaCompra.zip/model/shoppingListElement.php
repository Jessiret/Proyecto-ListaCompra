<?php
class ShoppingListElement
{
    private int $idProduct;
    private string $name;
    private float $quantity;
    private float $price;
    private string $categoria;
    //Constructor
    function __construct(int $idProduct, string $name, float $quantity, float $price, string $categoria)
    {
        $this->idProduct = $idProduct;
        $this->name = $name;
        $this->quantity = $quantity;
        $this->price = $price;
        $this->categoria = $categoria;
    }
    //Getters
    function getCategoria(){
        return $this->categoria;
    }
    function getIdProduct()
    {
        return $this->idProduct;
    }
    function getName()
    {
        return $this->name;
    }
    function getQuantity()
    {
        return $this->quantity;
    }
    function getPrice()
    {
        return $this->price;
    }
    //Setters
    function setCategoria($categoria){
        $this->categoria = $categoria;
    }
    function setIdProduct($idProduct)
    {
        $this->idProduct = $idProduct;
    }
    function setName($name)
    {
        $this->name = $name;
    }
    function setQuantity($quantity)
    {
        $this->quantity = $quantity;
    }
    function setPrice($price)
    {
        $this->price = $price;
    }
}
