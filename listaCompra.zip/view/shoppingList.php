<?php
include_once("model/shoppingListElement.php");
$ShoppingListElements = array();
$ShoppingListElements[0] = new ShoppingListElement(1, "Peras", 2, 1, "Fruta");
$ShoppingListElements[1] = new ShoppingListElement(2, "Tomillo", 3, 2, "Especias");
$ShoppingListElements[2] = new ShoppingListElement(3, "Avellanas", 1, 1, "Frutos secos");
$ShoppingListName = "Lista molona";
?>

<article class="panel is-primary">
    <p class=panel-heading style=text-align:center>
        Lista de la compra - <i><?= $ShoppingListName ?></i>
    </p>
    <div class="box">
        <table class="table is-fullwidth is-bordered is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Categoría</th>
                    <th>Cantidad</th>
                    <th>Total</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                foreach ($ShoppingListElements as $shoppingItem) {
                    $productTotal = $shoppingItem->getQuantity() * $shoppingItem->getPrice();
                    $total += $productTotal;
                    print("<tr><td>{$shoppingItem->getName()}</td><td>{$shoppingItem->getCategoria()}</td><td>{$shoppingItem->getQuantity()}</td><td>{$productTotal}</td></tr>");
                }
                print("<tfoot><th colspan=\"3\">TOTAL</th><th >$total</th></tfoot>");
                ?>
            </tbody>
        </table>
    </div>

</article>