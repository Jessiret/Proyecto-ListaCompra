<?php
include_once("model/user.php");
$user = new User(1, "Nombre usuario", "Correo@correo.com", "http://gravatar.com/avatar/b3b00f7ff897d0761582eac881253706?=200&d=robohash&r=x");

?>
<article class="panel is-primary">
    <p class="panel-heading">
        Información del usuario
    </p>
    <div class="card">
        <div class="card-image">
            <figure class="image is-4by3">
                <div><img src=<?= $user->getAvatarImage() ?>></div>
            </figure>
        </div>
        <div class="card-content">
            <div class="media">
                <div class="media-left">
                    <figure class="image is-48x48">
                        <img src=<?= $user->getAvatarImage() ?>alt="Placeholder image">
                    </figure>
                </div>
                <div class="media-content">
                    <p class="title is-4"><?= $user->getName() ?></p>
                    <p class="subtitle is-6"><?= $user->getEmail() ?></p>
         
                    
                </div>
            </div>

            <div class="content">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Phasellus nec iaculis mauris. <a>@bulmaio</a>.
                <a href="#">#css</a> <a href="#">#responsive</a>
                <br>
                <time datetime="2016-1-1">11:09 PM - 1 Jan 2016</time>
            </div>
        </div>
    </div>
</article>






